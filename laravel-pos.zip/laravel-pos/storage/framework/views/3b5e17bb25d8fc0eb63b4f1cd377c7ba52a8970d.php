

<?php $__env->startSection('title', 'Open POS'); ?>

<?php $__env->startSection('content'); ?>
    <div id="cart"></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel-pos\resources\views/cart/index.blade.php ENDPATH**/ ?>